' .NET 产品（ReSharper / dotMemory / dotTrace / dotCover 等）自动打补丁。
' 双击运行会弹框输入站点地址；也可：wscript install.vbs "https://example.com"
Option Explicit

Dim oShell, oFS
Set oShell = CreateObject("WScript.Shell")
Set oFS = CreateObject("Scripting.FileSystemObject")

' 取站点地址与提权标记
Dim sOrigin, bElevated
sOrigin = ""
bElevated = False
If WScript.Arguments.Count >= 1 Then sOrigin = WScript.Arguments(0)
If WScript.Arguments.Count >= 2 Then
    If UCase(WScript.Arguments(1)) = "ELEVATED" Then bElevated = True
End If

If sOrigin = "" Then
    sOrigin = InputBox("输入站点地址（如 https://example.com）：", "JetBrains .NET 补丁")
    If sOrigin = "" Then WScript.Quit
End If
Do While Right(sOrigin, 1) = "/"
    sOrigin = Left(sOrigin, Len(sOrigin) - 1)
Loop

' 自提权（patch Program Files 下的产品需要管理员）
If Not bElevated Then
    CreateObject("Shell.Application").ShellExecute "wscript.exe", _
        """" & WScript.ScriptFullName & """ """ & sOrigin & """ ELEVATED", "", "runas", 1
    WScript.Quit
End If

' 架构 -> 二进制名
Dim sArch, sRid, sBin, sUrl
sArch = UCase(oShell.ExpandEnvironmentStrings("%PROCESSOR_ARCHITECTURE%"))
If sArch = "ARM64" Then sRid = "arm64" Else sRid = "x64"
sBin = "jb-dotnet-patcher-win-" & sRid & ".exe"
sUrl = sOrigin & "/static/dotnet-patcher/" & sBin

' 定位产品
Dim oFound
Set oFound = CreateObject("Scripting.Dictionary")
FindDll oShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\JetBrains"), "jetbrains.platform.shell.dll"
FindDll oShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs"), "jetbrains.platform.shell.dll"
FindDll oShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\JetBrains"), "jetbrains.platform.shell.dll"
FindDll oShell.ExpandEnvironmentStrings("%ProgramFiles%\JetBrains"), "jetbrains.platform.shell.dll"

If oFound.Count = 0 Then
    MsgBox "未找到任何 .NET 产品（JetBrains.Platform.Shell.dll）。", vbOKOnly Or vbExclamation
    WScript.Quit 1
End If

' 下载 patcher
Dim sExe
sExe = oShell.ExpandEnvironmentStrings("%TEMP%") & "\" & sBin
If Not Download(sUrl, sExe) Then
    MsgBox "下载 patcher 失败：" & sUrl, vbOKOnly Or vbCritical
    WScript.Quit 1
End If

' 逐个 patch
Dim p, n
n = 0
For Each p In oFound.Keys
    oShell.Run """" & sExe & """ """ & p & """", 0, True
    n = n + 1
Next

oFS.DeleteFile sExe, True
MsgBox "完成，已处理 " & n & " 个 .NET 产品。" & vbCrLf & "用对应激活码激活即可；卸载请运行 uninstall.vbs。", vbOKOnly Or vbInformation

' 递归查找指定文件名，去重收集到 oFound
Sub FindDll(ByVal sFolder, ByVal sTarget)
    If Not oFS.FolderExists(sFolder) Then Exit Sub
    Dim f, sf
    On Error Resume Next
    For Each f In oFS.GetFolder(sFolder).Files
        If LCase(f.Name) = sTarget Then
            If Not oFound.Exists(f.Path) Then oFound.Add f.Path, 1
        End If
    Next
    For Each sf In oFS.GetFolder(sFolder).SubFolders
        FindDll sf.Path, sTarget
    Next
    On Error GoTo 0
End Sub

Function Download(ByVal sUrl, ByVal sDest)
    Dim http, stream
    Download = False
    On Error Resume Next
    Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
    http.Open "GET", sUrl, False
    http.Send
    If Err.Number <> 0 Or http.Status <> 200 Then Exit Function
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1 ' binary
    stream.Open
    stream.Write http.ResponseBody
    stream.SaveToFile sDest, 2 ' overwrite
    stream.Close
    If Err.Number = 0 Then Download = True
    On Error GoTo 0
End Function
