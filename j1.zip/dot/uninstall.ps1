﻿# 还原 .NET 产品补丁：把 JetBrains.Platform.Shell.dll.bak 恢复成原文件。
# 用法：双击 uninstall.bat，或：
#   powershell -NoProfile -ExecutionPolicy Bypass -File uninstall.ps1
$ErrorActionPreference = 'Stop'

$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host '需要管理员权限，正在提权...' -ForegroundColor Yellow
    Start-Process powershell -Verb RunAs -Wait -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"")
    exit
}

function Info($m){ Write-Host "==> $m" -ForegroundColor Cyan }
function Ok($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m){ Write-Host "[!]  $m" -ForegroundColor Yellow }

Info '查找备份 JetBrains.Platform.Shell.dll.bak ...'
$roots = @(
    (Join-Path $env:LOCALAPPDATA 'JetBrains'),
    (Join-Path $env:LOCALAPPDATA 'Programs'),
    (Join-Path ${env:ProgramFiles(x86)} 'JetBrains'),
    (Join-Path $env:ProgramFiles 'JetBrains')
)
$found = 0
foreach ($r in $roots) {
    if (-not (Test-Path $r)) { continue }
    foreach ($bak in Get-ChildItem -Path $r -Recurse -Filter 'JetBrains.Platform.Shell.dll.bak' -File -ErrorAction SilentlyContinue) {
        $dll = $bak.FullName.Substring(0, $bak.FullName.Length - 4)
        Move-Item -LiteralPath $bak.FullName -Destination $dll -Force
        Ok "已还原: $dll"
        $found++
    }
}
if ($found -gt 0) { Ok '完成。' } else { Warn '未找到任何备份，无需还原。' }
Read-Host '按回车退出'
