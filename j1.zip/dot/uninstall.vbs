' 还原 .NET 产品补丁：把 JetBrains.Platform.Shell.dll.bak 恢复成原文件。
' 双击运行即可。
Option Explicit

Dim oShell, oFS
Set oShell = CreateObject("WScript.Shell")
Set oFS = CreateObject("Scripting.FileSystemObject")

' 自提权
Dim bElevated
bElevated = False
If WScript.Arguments.Count >= 1 Then
    If UCase(WScript.Arguments(0)) = "ELEVATED" Then bElevated = True
End If
If Not bElevated Then
    CreateObject("Shell.Application").ShellExecute "wscript.exe", _
        """" & WScript.ScriptFullName & """ ELEVATED", "", "runas", 1
    WScript.Quit
End If

Dim oFound
Set oFound = CreateObject("Scripting.Dictionary")
FindBak oShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\JetBrains")
FindBak oShell.ExpandEnvironmentStrings("%LOCALAPPDATA%\Programs")
FindBak oShell.ExpandEnvironmentStrings("%ProgramFiles(x86)%\JetBrains")
FindBak oShell.ExpandEnvironmentStrings("%ProgramFiles%\JetBrains")

If oFound.Count = 0 Then
    MsgBox "未找到任何备份，无需还原。", vbOKOnly Or vbInformation
    WScript.Quit
End If

Dim p, dst, n
n = 0
For Each p In oFound.Keys
    dst = Left(p, Len(p) - 4) ' 去掉 .bak
    If oFS.FileExists(dst) Then oFS.DeleteFile dst, True
    oFS.MoveFile p, dst
    n = n + 1
Next

MsgBox "完成，已还原 " & n & " 个 .NET 产品。", vbOKOnly Or vbInformation

Sub FindBak(ByVal sFolder)
    If Not oFS.FolderExists(sFolder) Then Exit Sub
    Dim f, sf
    On Error Resume Next
    For Each f In oFS.GetFolder(sFolder).Files
        If LCase(f.Name) = "jetbrains.platform.shell.dll.bak" Then
            If Not oFound.Exists(f.Path) Then oFound.Add f.Path, 1
        End If
    Next
    For Each sf In oFS.GetFolder(sFolder).SubFolders
        FindBak sf.Path
    Next
    On Error GoTo 0
End Sub
