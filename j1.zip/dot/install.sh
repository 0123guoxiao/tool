#!/usr/bin/env bash
# .NET 产品（dotMemory / dotTrace / dotCover / ReSharper 等）自动打补丁。
# 用法：
#   curl -fsSL <站点>/static/ja-netfilter/dot/install.sh | bash -s -- <站点>
#   或：JB_ORIGIN=<站点> ./install.sh
# <站点> 形如 https://example.com （不带结尾斜杠也行）。
set -euo pipefail

# 彩色输出（非终端时自动关闭，避免管道里出现乱码）。
if [ -t 1 ]; then
    C_R=$'\033[31m'; C_G=$'\033[32m'; C_Y=$'\033[33m'; C_B=$'\033[36m'; C_0=$'\033[0m'
else
    C_R=; C_G=; C_Y=; C_B=; C_0=
fi
info()  { printf '%s==>%s %s\n' "$C_B" "$C_0" "$*"; }
ok()    { printf '%s✓%s %s\n'  "$C_G" "$C_0" "$*"; }
warn()  { printf '%s!%s %s\n'  "$C_Y" "$C_0" "$*" >&2; }
fail()  { printf '%s✗%s %s\n'  "$C_R" "$C_0" "$*" >&2; exit 1; }

BASE_URL="${1:-${JB_ORIGIN:-}}"
[ -n "$BASE_URL" ] || fail "需要站点地址。用法: install.sh <站点>"
BASE_URL="${BASE_URL%/}"

case "$(uname -s)" in
    Darwin) plat=osx ;;
    Linux)  plat=linux ;;
    *) fail "不支持的系统: $(uname -s)" ;;
esac
case "$(uname -m)" in
    x86_64|amd64)   arch=x64 ;;
    arm64|aarch64)  arch=arm64 ;;
    *) fail "不支持的架构: $(uname -m)" ;;
esac

bin="jb-dotnet-patcher-$plat-$arch"
url="$BASE_URL/static/dotnet-patcher/$bin"

info "查找 JetBrains.Platform.Shell.dll ..."
if [ "$plat" = osx ]; then
    roots="/Applications $HOME/Applications $HOME/Library/Application Support/JetBrains"
else
    roots="$HOME/.local/share/JetBrains /opt/JetBrains /opt"
fi
dlls=""
for r in $roots; do
    [ -d "$r" ] || continue
    while IFS= read -r -d '' f; do
        dlls="$dlls$f
"
    done < <(find "$r" -name 'JetBrains.Platform.Shell.dll' -print0 2>/dev/null)
done
[ -n "$dlls" ] || fail "未找到任何 .NET 产品（JetBrains.Platform.Shell.dll）。"

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT

# 下载（带进度条）
info "下载 patcher: $url"
curl -fL --progress-bar "$url" -o "$tmp/patcher" || fail "下载失败: $url"

# 校验 sha256
expected="$(curl -fsSL "$url.sha256" 2>/dev/null | tr -d ' \r\n' | tr 'A-F' 'a-f' || true)"
if [ -n "$expected" ]; then
    if command -v sha256sum >/dev/null 2>&1; then
        actual="$(sha256sum "$tmp/patcher" | awk '{print $1}')"
    else
        actual="$(shasum -a 256 "$tmp/patcher" | awk '{print $1}')"
    fi
    [ "$actual" = "$expected" ] || fail "sha256 校验失败：期望 $expected 实际 $actual"
    ok "sha256 校验通过"
else
    warn "未取到 sha256，跳过校验"
fi

chmod +x "$tmp/patcher"
if [ "$plat" = osx ]; then
    xattr -dr com.apple.quarantine "$tmp/patcher" 2>/dev/null || true
    warn "若 macOS 提示 patcher「已损坏」或无法验证开发者，请打开 系统设置 > 隐私与安全性，在底部点「仍要打开 / 仍要运行」后重试。"
fi

info "开始打补丁（请确保相关程序已退出）..."
echo "$dlls" | while IFS= read -r f; do
    [ -n "$f" ] && "$tmp/patcher" "$f"
done

ok "完成。用对应激活码激活即可；卸载请运行 uninstall.sh。"
