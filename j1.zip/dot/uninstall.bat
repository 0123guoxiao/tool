@echo off
rem 双击启动：以 Bypass 执行策略调用 uninstall.ps1（ps1 内部自提权）
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %*
