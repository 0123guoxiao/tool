﻿# .NET 产品（ReSharper / dotTrace / dotMemory / dotCover 等）自动打补丁。
# 用法：双击 install.bat，或：
#   powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 [站点地址]
param([string]$Origin)
$ErrorActionPreference = 'Stop'

if (-not $Origin) { $Origin = Read-Host '输入站点地址（如 https://example.com）' }
if (-not $Origin) { Write-Host '未提供站点地址，退出。' -ForegroundColor Red; exit 1 }
$Origin = $Origin.TrimEnd('/')

# 自提权（patch Program Files 下的产品需要管理员）
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host '需要管理员权限，正在提权...' -ForegroundColor Yellow
    Start-Process powershell -Verb RunAs -Wait -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',"`"$PSCommandPath`"",$Origin)
    exit
}

function Info($m){ Write-Host "==> $m" -ForegroundColor Cyan }
function Ok($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m){ Write-Host "[!]  $m" -ForegroundColor Yellow }
function Die($m){ Write-Host "[X]  $m" -ForegroundColor Red; Read-Host '按回车退出'; exit 1 }

if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { $rid = 'arm64' } else { $rid = 'x64' }
$bin = "jb-dotnet-patcher-win-$rid.exe"
$url = "$Origin/static/dotnet-patcher/$bin"

Info '查找 JetBrains.Platform.Shell.dll ...'
$roots = @(
    (Join-Path $env:LOCALAPPDATA 'JetBrains'),
    (Join-Path $env:LOCALAPPDATA 'Programs'),
    (Join-Path ${env:ProgramFiles(x86)} 'JetBrains'),
    (Join-Path $env:ProgramFiles 'JetBrains')
)
$dlls = @()
foreach ($r in $roots) {
    if (Test-Path $r) {
        $dlls += Get-ChildItem -Path $r -Recurse -Filter 'JetBrains.Platform.Shell.dll' -File -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty FullName
    }
}
$dlls = $dlls | Sort-Object -Unique
if ($dlls.Count -eq 0) { Die '未找到任何 .NET 产品（JetBrains.Platform.Shell.dll）。' }

$tmp = Join-Path $env:TEMP $bin
Info "下载 patcher: $url"
try {
    Import-Module BitsTransfer -ErrorAction Stop
    Start-BitsTransfer -Source $url -Destination $tmp -DisplayName 'jb-dotnet-patcher' -ErrorAction Stop
} catch {
    $ProgressPreference = 'Continue'
    try { Invoke-WebRequest -Uri $url -OutFile $tmp } catch { Die "下载失败: $url" }
}

# 校验 sha256
$expected = $null
try { $expected = (Invoke-WebRequest -Uri "$url.sha256" -UseBasicParsing).Content.Trim().ToLower() } catch {}
if ($expected) {
    $actual = (Get-FileHash -Algorithm SHA256 -Path $tmp).Hash.ToLower()
    if ($actual -ne $expected) { Die "sha256 校验失败：期望 $expected 实际 $actual" }
    Ok 'sha256 校验通过'
} else {
    Warn '未取到 sha256，跳过校验'
}

Info '开始打补丁（请确保相关程序已退出）...'
$n = 0
foreach ($p in $dlls) { & $tmp $p; $n++ }
Remove-Item $tmp -Force -ErrorAction SilentlyContinue

Ok "完成，已处理 $n 个 .NET 产品。用对应激活码激活即可；卸载请运行 uninstall.bat。"
Read-Host '按回车退出'
