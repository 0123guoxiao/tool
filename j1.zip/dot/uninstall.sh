#!/usr/bin/env bash
# 还原 .NET 产品补丁：把 JetBrains.Platform.Shell.dll.bak 恢复成原文件。
# 用法：curl -fsSL <站点>/static/ja-netfilter/dot/uninstall.sh | bash
#   或：./uninstall.sh
set -euo pipefail

if [ -t 1 ]; then
    C_G=$'\033[32m'; C_Y=$'\033[33m'; C_B=$'\033[36m'; C_0=$'\033[0m'
else
    C_G=; C_Y=; C_B=; C_0=
fi

case "$(uname -s)" in
    Darwin) roots="/Applications $HOME/Applications $HOME/Library/Application Support/JetBrains" ;;
    Linux)  roots="$HOME/.local/share/JetBrains /opt/JetBrains /opt" ;;
    *) printf '%s✗%s 不支持的系统: %s\n' "$C_Y" "$C_0" "$(uname -s)" >&2; exit 1 ;;
esac

printf '%s==>%s 查找备份 JetBrains.Platform.Shell.dll.bak ...\n' "$C_B" "$C_0"
found=0
for r in $roots; do
    [ -d "$r" ] || continue
    while IFS= read -r -d '' bak; do
        mv -f "$bak" "${bak%.bak}"
        printf '%s✓%s 已还原: %s\n' "$C_G" "$C_0" "${bak%.bak}"
        found=1
    done < <(find "$r" -name 'JetBrains.Platform.Shell.dll.bak' -print0 2>/dev/null)
done

if [ "$found" = 1 ]; then
    printf '%s✓%s 完成。\n' "$C_G" "$C_0"
else
    printf '%s!%s 未找到任何备份，无需还原。\n' "$C_Y" "$C_0"
fi
